<?php   
if($_SERVER['REQUEST_METHOD'] == 'POST') {
 
  // Handle form values sent by addEmployee.php
  $firstplace = $_POST['fromPlace'];
  echo "form parameters"  .$firstplace. "<br/>";
  $secondplace = $_POST['toPlace'];
  $time = $_POST['time'];
 // @TODO: your database code should  here
  //---------------------------------------------------



      // 1 - Database information
     include_once'../connect.php';

      // 3 - Make the SQL query and send to database
 $sql= "INSERT INTO routes";
  $sql.= "(from_place, to_place, time_set,day)";
    $sql.= "VALUES ";
	 $sql.= "(";
	  $sql.= "'".$firstplace."',";
	  	  $sql.= "'".$secondplace."',";
		  	  $sql.= "'".$time."','1'";
	 
	  $sql.= ")";
    echo $sql;
	
$result = mysqli_query($connection,$sql);
if ($result == TRUE) {
  echo "<h1> SUCCESS</h1>";
}
else
{
echo "Database query failed. <br/>";
  echo "SQL command: " . $sql;
  exit();	
}

  //---------------------------------------------------
  

   } 
 else {
  // you got a GET request, so
  // redirect person back to add employee page
  header("Location: " . "addbus.php");
  exit();
  }
?>
