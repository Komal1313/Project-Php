<?php
  if(!isset($_REQUEST['id'])){
      header('Location:index.php');
  }

  include_once'../connect.php';

   if(isset($_REQUEST['up'])){
      extract($_REQUEST);
      $qr="update routes set from_place='$fromPlace' , to_place='$toPlace' , time_set='$time' where id=$id";
      $rt=mysqli_query($connection,$qr);
      if($rt){
        echo "<h1>Data Updated</h1>";
      }else{
          echo "<h1>Data Not Updated</h1>";
      }
  }

   
$id=$_REQUEST['id'];
  
  $q="select * from routes where id=$id";
  $r=mysqli_query($connection,$q);
  if($row=mysqli_fetch_array($r)){
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
    <header>
      <br>
      <br>
    </header>


    <nav>
      <div class="btn-group btn-group-justified">
    <a href="index.php" class="btn btn-primary">Home</a>
    <a href="list.php" class="btn btn-primary">List Of Busses</a>
    <a href="addbus.php" class="btn btn-primary">Add New Bus</a>
    <a href="logout.php" class="btn btn-primary">Sign Out</a>
  </div>    
    </nav>
<br>
  <br>
  <br>
  <br>
  <div class="container">
    
      <div class="panel panel-default">
    <div class="panel-heading"><h3 class="c">Update Bus Schedule</h3></div>
    <div class="panel-body"> 
        <form action = "" method ="post" input type="hidden" name="id" value="<?php echo $id ?>"  />

          <div> 
            <label class="form-label" for="fromPlace">Pick Up Location</label>
            <select class="form-control" input  required  type="text" name="fromPlace" value=""  />
              <option>Choose Location</option>
              <option>Lambton College</option>
              <option>Square One,Mississauga</option>
              <option>Charolais Blvd,near the Beer Store,Brampton</option>
                
            </select>
          </div>
          <br>
          
          <div>
            <label class="form-label" for="toPlace">Destination</label>
            <select class="form-control" input required  type="text" name="toPlace" value="" />
              <option>Choose Location</option>
              <option>Lambton College</option>
              <option>Square One,Mississauga</option> 
              <option>Charolais Blvd,near the Beer Store,Brampton</option>
               
            </select>
          </div>
          <br>
          
            <div>

            <label class="form-label" for="time">Time</label>
            <input  required type="time" name="time" value=""/>
          </div>
            <div class="c"> 
            <p><input  required  type="submit" class="btn btn-primary" name="up" value="Update" /></p>
            </div>
        </div> 
     
<div class="panel-footer">
          <p>
            <a href="index.php" class="btn btn-primary">Go Back </a>
          </p>
</div>
</div>
</form>
        
   </div>
   <br>
   <br>

    <footer>
      &copy; <?php echo date("Y") ?> Cestar College
    </footer>

  </body>
</html>

<?php
}else{

  echo "<h1>NO Such Route is Present</h1>";
}

?>



