
<?php

  session_start();
  ob_start();
  if($_SESSION['uname']==""){
    header("Location:../index.php");
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
    <header>
      <br>
      <br>
    </header>

    <nav>
 <span>     
  <div class="btn-group btn-group-justified">
    <a href="index.php" class="btn btn-primary">Home</a>
    <a href="list.php" class="btn btn-primary">List Of Busses</a>
    <a href="addbus.php" class="btn btn-info active">Add New Bus</a>
    <a href="logout.php" class="btn btn-primary">Sign Out</a>
  </div>   
</span>
  </nav>
  <br>
  <br>
  <div class="container">
<div class="panel panel-default">
    <div class="panel-heading"><h3 class="c">Add New Bus</h3>
    </div>
  <div class="panel-body"> 
    <?php   
if($_SERVER['REQUEST_METHOD'] == 'POST') {
 
  // Handle form values sent by addEmployee.php
  $firstplace = $_POST['fromPlace'];
 
  $secondplace = $_POST['toPlace'];
  $time = $_POST['time'];
 // @TODO: your database code should  here
  //---------------------------------------------------



      // 1 - Database information
     include_once'../connect.php';

      // 3 - Make the SQL query and send to database
 $sql= "INSERT INTO routes";
  $sql.= "(from_place, to_place, time_set,day)";
    $sql.= "VALUES ";
   $sql.= "(";
    $sql.= "'".$firstplace."',";
        $sql.= "'".$secondplace."',";
          $sql.= "'".$time."','1'";
   
    $sql.= ")";
    
  
$result = mysqli_query($connection,$sql);
if ($result == TRUE) {
  echo "<h1> SUCCESS</h1>";
}
else
{
echo "Database query failed. <br/>";
  echo "SQL command: " . $sql;
  exit(); 
}

  //---------------------------------------------------
  

   } 
 
?>


      <form class="form-inline-justified" action="" method="POST" class="form-group">
      

      <div>
      <label class="form-label" for="fromPlace">From:</label>
      <select class="form-control" id="" input required type="text" name="fromPlace" value="" /> 
      <option>Choose Location</option>
        <option>Lambton College</option>
        <option>Charolais Blvd,near the Beer Store,Brampton</option>
        <option>Square One,Mississauga</option>  
      </select>
      </div>
<br>
  <div>
    <label class="form-label" for="toPlace">To:</label>
    <select class="form-control" id="" input required type="text"   name="toPlace" value=""="" placeholder="choose one location" />
      <option>Choose Location</option>
      <option>Lambton College</option>
      <option>Charolais Blvd,near the Beer Store,Brampton</option>
      <option>Square One,Mississauga</option>  
    </select>
  </div>
        
  <br>
  <br>
<div>
      <label class="form-label" for="time">Time</label>
      <input  required type="time" name="time" value="" />
</div>
      <br>


  <div class="c">
  
    <button type="submit" class="btn btn-primary"  value="Add" > Add </button>     
  </div>
    </div>
    <div class="panel-footer">
  <a href="index.php" class="btn btn-primary">Go Back </a>
</div>
</div>
</form>
</div>
  <footer>
      &copy;<?php echo date("Y") ?>  Cestar College
    </footer>
  </body>
</html>
