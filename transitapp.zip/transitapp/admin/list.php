<?php

  session_start();
  ob_start();
  if($_SESSION['uname']==""){
    header("Location:../index.php");
  }
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
    <header>
      <br>
      <br>
    </header>
 <?php

  include_once'../connect.php';
                $query = "SELECT * FROM routes";

      $result = mysqli_query($connection, $query);

      // 4 - Handle the response from database
      if ($result == FALSE) {
        echo "Database query failed. <br/>";
        echo "SQL command: " . $query;
        exit();
      }
    ?>


    <nav>
 
 <div class="btn-group btn-group-justified">
    <a href="index.php" class="btn btn-primary">Home</a>
    <a href="list.php" class="btn btn-info active">List Of Busses</a>
    <a href="addbus.php" class="btn btn-primary">Add New Bus</a>
    <a href="logout.php" class="btn btn-primary">Sign Out</a>
  </div>    

    </nav>
    <br>
    <br>
    <div class="container">
    	<table  class="table table-striped table-hover">
    <tr>
    <th>ID</th>

	<th>Pick-up Location</th>
	<th>Destination</th>
	<th><span class="glyphicon glyphicon-time"></span> </th>
  <th>View</th>
  <th>Update</th>
  <th>Delete</th>
	<th> &nbsp; </th>
	<th>  &nbsp; </th>
	<th>  &nbsp; </th>
    </tr>
  <?php while ($getRoute = mysqli_fetch_assoc($result)) { ?>
   <tr>
    <td><?php echo $getRoute['id']; ?></td>

                <td><?php echo $getRoute['from_place']; ?></td>
                <td><?php echo $getRoute['to_place']; ?></td>
                <td><?php echo $getRoute['time_set']; ?></td>
		<th>
      <a href="viewbus.php?id='<?php $getRoute['id'];?>'" class="btn btn-info btn-lg">
       <span class="glyphicon glyphicon-eye-open"></span>
     </a>
    </th> 
			<th>  
        <a href="<?php echo 'edit.php?id=' . $getRoute['id']; ?>" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-pencil"></span>  
        </a> </th>

			<th> 
        <a href="<?php echo 'deletebus.php?id='. $getRoute["id"]; 
        ?>"class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-trash"></span>
      </a></th>
			<?php } ?>	
   
  </tr>
  </table>
    </div>
    <br>
    <br>
    <footer>
      &copy;<?php echo date("Y") ?>  Cestar College
    </footer>



  </body>
</html>
