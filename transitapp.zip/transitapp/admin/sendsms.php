<!DOCTYPE html>
<html>
  <head>
<meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
    <header>
      <br>
      <br>
    </header>

    <nav>
    	<div class="container">
    <div class="panel panel-default">
    <div class="panel-heading"  ><h4 class="c">Bus Delay Message has been sent to students</h4></div>
    

<?php
require __DIR__ . '/twilio-php-master/Twilio/autoload.php';

use Twilio\Rest\Client;

echo "Sending SMS! <br>";
// Your Account SID and Auth Token from twilio.com/console
$account_sid = 'ACc7885adda03ba1f39b3caac83dd090ca';
$auth_token = 'f29d894fd145eca7f5957c05f398b5ac';

// A Twilio number you own with SMS capabilities
$twilio_number = "+16139094737";

$client = new Client($account_sid, $auth_token);
$client->messages->create(
    // Where to send a text message (your cell phone?)
    '+16477410048',
    array(
        'from' => $twilio_number,
        'body' => 'Bus is delay!'
    )
);

echo "Done sending SMS! <br>";

?>
</div>

</div>
</nav>
</body></html>