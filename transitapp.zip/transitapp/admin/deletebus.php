<?php
  if (isset($_GET["id"]) == FALSE) {
    // missing an id parameters, so
    // redirect person back to add employee page
    header("Location: " . "index.php");
    exit();
  }

  // save the ID so you can use it later
  $id = $_GET["id"];

  // check for a POST request
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // @TODO: your database code should  here
    //---------------------------------------------------


    //---------------------------------------------------

    // @TODO: delete these two statements after you are done adding your database code
    echo "I got a POST request! <br/>";
    print_r($_POST);
  }

?>
<!DOCTYPE html>
<html>
  <head>
<meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
    <header>
      <br>
      <br>
    </header>

    <nav>
      <div class="btn-group btn-group-justified">
    <a href="index.php" class="btn btn-primary">Home</a>
    <a href="list.php" class="btn btn-primary">List Of Busses</a>
    <a href="addbus.php" class="btn btn-primary">Add New Bus</a>
    <a href="logout.php" class="btn btn-primary">Sign Out</a>
  </div> 
      
       
      <br>
      <br>
    </nav>
    <div class="container">
    <div class="panel panel-default">
    <div class="panel-heading"  ><h4 class="c">Delete Bus From Schedule</h4></div>
    <div class="panel-body"> 
      <form class="form-inline-justified">
<?php
 include_once'../connect.php';
 
$sql = "DELETE FROM routes ";
$sql .= "WHERE id='" . $id."'";
$sql .= "LIMIT 1";

	$result = mysqli_query($connection, $sql);
	if ($result == FALSE) {

		echo "Database query failed. <br/>";
		echo "SQL command: " . $query;
		exit();
	}
	mysqli_close($connection);

?>
         
      <h4> ARE YOU SURE YOU WANNA DELETE?! </h4>
				<form action = "<?php echo "deletebus.php?id=" . $id; ?>" method ="POST">
        </div>
          <div class="panel-footer" >
				<button type="submit" class="btn-primary" class="c" name="choice"> Yes! </button>
     
			</form>
      </div> 
    </div> 

<br>
<br>
    <footer>
      &copy; <?php echo date("Y") ?> Cestar College
    </footer>

  </body>
</html>
