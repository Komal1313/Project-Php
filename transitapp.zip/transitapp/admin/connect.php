<?php

	$dbhost = "localhost";
            $dbuser = "root";
            $dbpass = "";
            $dbname = "transitbus";
            // 2 - Connect to the database and handle any connection errors
            $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
            if (mysqli_connect_errno())
            {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
             exit();
            }
?>